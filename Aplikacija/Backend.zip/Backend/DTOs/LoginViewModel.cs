using System.ComponentModel.DataAnnotations;

namespace Backend.DTOs
{
    public class LoginViewModel
    {
        public required string Username {get;set;}
        public required string Password{get;set;}
    }
}